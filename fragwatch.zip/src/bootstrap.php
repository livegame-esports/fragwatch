<?php

const APP_DIR = __DIR__;
const ROOT_DIR = __DIR__ . '/..';

include __DIR__ . '/bot/Telegram.php';
