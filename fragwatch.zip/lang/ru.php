<?php

return [
    'view_players' => '🎮 Посмотреть игроков',
    'update' => '🔄 Обновить',
    'back' => '🔙 Назад',
    'no_players' => 'На сервере нет игроков.',
    'current_players' => '🎮 <b>Текущие игроки (%d)</b>',
    'kills' => 'Убийства',
    'time' => '⏱ Время',
    'ip' => 'IP',
    'map' => 'Карта',
    'players' => 'Игроки',
];
