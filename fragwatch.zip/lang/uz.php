<?php

return [
    'view_players' => '🎮 O‘yinchilarni ko‘rish',
    'update' => '🔄 Yangilash',
    'back' => '🔙 Orqaga',
    'no_players' => "Serverda o'yinchilar yo'q.",
    'current_players' => "🎮 <b>Hozirgi o'yinchilar (%d)</b>",
    'kills' => 'Kills',
    'time' => '⏱ Vaqt',
    'ip' => 'IP',
    'map' => 'Map',
    'players' => 'O‘yinchilar',
];
